<?php 
/*
* Template Name: Multi Step Form1
*/
get_header() ?>


<style>
.form {
    margin-top: 57px;
    max-height: 640px;
    min-height: 520px;
    background: #238ac5;
    height: 72%;
    padding: 100px 0;
}    


#example-form ul[role="tablist"]{
   display: table;
    margin: auto;
    padding: 0;
}
#example-form ul[role="tablist"] li{
    text-indent: inherit;
    width: 40px;
    height: 40px;
    margin-right: 10px;
    border-radius: 50%;
       color: #fff;
    font-size: 20px;
    border: 2px solid #fff;
    padding: 4px 0;
    opacity: .5;
    cursor: default;
    color: #fff;
        display: inline-block !important;
}
#example-form ul[role="tablist"] li.current{
    background-color: #fff;
    opacity: 1;
    }
#example-form ul[role="tablist"] li.current a span.number{
 color: #333 !important;
    opacity: 1 !important;
}

#example-form ul[role="tablist"] li a span.current-info{display: none;}
#example-form ul[role="tablist"] li a span.number{
        display: block;
    text-align: center;
    text-indent: inherit;
    font-size: 20px;
       color: #fff;
    opacity: .5;
    cursor: default;
 
}
#example-form ul[role="tablist"] li a{font-size: 0}




#example-form section h2{    
    text-align: center;
    font-size: 2.5em;
    border-top: 1px solid #fff;
    border-bottom: 1px solid #fff;
    padding: 20px 35px;
    position: relative;
    margin-top: 41px;
    line-height: 1.2em;
    color: #fff;
    text-transform: uppercase;
    font-weight: 600;
}
#example-form section h2 i{
    font-size: 21px;
    text-shadow: 0px 2px 3px #0000006b;
    position: relative;
    top: -26px;
    margin-left: -27px;
    left: 17px;
    position: relative;
}
</style>



<section class="form">
 <div class="container">
   <form id="example-form" action="#">
    <div>
        <h3></h3>
        <section>

            <h2> Business Operating Time<i title="" data-toggle="tooltip" data-placement="bottom" class="fa fa-fw fa-question-circle" data-original-title="The period of time your business has been operating since its establishment until now."></i><br></h2>

        </section>

        <h3></h3>
        <section>

        </section>

        <h3></h3>
        <section>

        </section>
    </div>
</form>       
</div>
</section>




<?php get_footer() ?>

<script src="<?php echo get_stylesheet_directory_uri(); ?>/custom/jquery.steps.min.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/custom/jquery.validate.min.js"></script>

<script>
    
/**
 * Custom validator for contains at least one lower-case letter
 */
jQuery.validator.addMethod("atLeastOneLowercaseLetter", function (value, element) {
    return this.optional(element) || /[a-z]+/.test(value);
}, "Must have at least one lowercase letter");
 
/**
 * Custom validator for contains at least one upper-case letter.
 */
jQuery.validator.addMethod("atLeastOneUppercaseLetter", function (value, element) {
    return this.optional(element) || /[A-Z]+/.test(value);
}, "Must have at least one uppercase letter");
 
/**
 * Custom validator for contains at least one number.
 */
jQuery.validator.addMethod("atLeastOneNumber", function (value, element) {
    return this.optional(element) || /[0-9]+/.test(value);
}, "Must have at least one number");
 
/**
 * Custom validator for contains at least one symbol. 
 */
jQuery.validator.addMethod("atLeastOneSymbol", function (value, element) {
    return this.optional(element) || /[!@#$%^&*()]+/.test(value);
}, "Must have at least one symbol");

//
    var form = jQuery("#example-form");
    form.validate({
        errorPlacement: function errorPlacement(error, element) { element.before(error); },
        rules: {
            userName: {
                required: true,
                atLeastOneLowercaseLetter: true,
                minlength: 4,
                maxlength: 40,
                remote: {
                    url: "<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=cms_checkusername",
                    type: "post"
                }
            },
            kvk_number: {
                required: true,
                remote: {
                    url: "<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=cms_kvk_number",
                    type: "post"
                }
            },
            userEmail: {
                required: true,
                email: true,
                remote: {
                    url: "<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=cms_checkemail",
                    type: "post"
                }
            },          
            confirm: {
                equalTo: "#password"
            }
        },
        messages: {
            userName: {
                required: "Please enter your Username",
                remote: "Username is already in use!"
            },
            userEmail: {
                required: "Please enter your Email address.",
                remote: "Email is already in use!"
            },
            kvk_number: {
                required: "Please enter your Kvk Number",
                remote: "Your KVK is'nt verified!"
            }
        },
    });
    form.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging: function (event, currentIndex, newIndex)
        {
            form.validate().settings.ignore = ":disabled,:hidden";
            return form.valid();
        },
        onFinishing: function (event, currentIndex){
            form.validate().settings.ignore = ":disabled";
            return form.valid();
        },
        onFinished: function (event, currentIndex){
            jQuery('.loader-css').show();
            var formData = new FormData(jQuery(form)[0]);
            jQuery.ajax({
                type: 'post',  
                url: '<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=cms_formsubmit',  
                dataType: 'json',
                contentType: false,
                processData: false,
                data: formData,
            })
            .done(function(value) {
                jQuery('.errrrrrr').remove();
                if (value.class == 'isa_error isa_sucess') {
                    form.trigger('reset');
                    jQuery('.loader-css').hide();
                }
                form.append('<div class="container errrrrrr"><div class="'+value.class+'">'+value.msg+'</div></div>');
                jQuery('.loader-css').hide();
                console.log(value);
            })
            .fail(function() {
                jQuery('.loader-css').hide();
                console.log("error");
            });



        }
    });
</script>
